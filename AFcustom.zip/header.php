<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, minimum-scale=1.0">
    
	<title>Amelia Fowler</title>
    
    <link rel="stylesheet" href="style.css">
        
    
</head>



<body id="home">
	
<!-- INLINE SVG: MAKE THIS AN INCLUDE -->	
<svg style="position: absolute; width: 0; height: 0;" width="0" height="0" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">
<defs>
<symbol id="icon-menu" viewBox="0 0 32 32">
<title>menu</title>
<path class="path1" d="M2 6h28v6h-28zM2 14h28v6h-28zM2 22h28v6h-28z"></path>
</symbol>
<symbol id="icon-cross" viewBox="0 0 32 32">
<title>cross</title>
<path class="path1" d="M31.708 25.708c-0-0-0-0-0-0l-9.708-9.708 9.708-9.708c0-0 0-0 0-0 0.105-0.105 0.18-0.227 0.229-0.357 0.133-0.356 0.057-0.771-0.229-1.057l-4.586-4.586c-0.286-0.286-0.702-0.361-1.057-0.229-0.13 0.048-0.252 0.124-0.357 0.228 0 0-0 0-0 0l-9.708 9.708-9.708-9.708c-0-0-0-0-0-0-0.105-0.104-0.227-0.18-0.357-0.228-0.356-0.133-0.771-0.057-1.057 0.229l-4.586 4.586c-0.286 0.286-0.361 0.702-0.229 1.057 0.049 0.13 0.124 0.252 0.229 0.357 0 0 0 0 0 0l9.708 9.708-9.708 9.708c-0 0-0 0-0 0-0.104 0.105-0.18 0.227-0.229 0.357-0.133 0.355-0.057 0.771 0.229 1.057l4.586 4.586c0.286 0.286 0.702 0.361 1.057 0.229 0.13-0.049 0.252-0.124 0.357-0.229 0-0 0-0 0-0l9.708-9.708 9.708 9.708c0 0 0 0 0 0 0.105 0.105 0.227 0.18 0.357 0.229 0.356 0.133 0.771 0.057 1.057-0.229l4.586-4.586c0.286-0.286 0.362-0.702 0.229-1.057-0.049-0.13-0.124-0.252-0.229-0.357z"></path>
</symbol>
</defs>
</svg>
<!-- INLINE SVG: MAKE THIS AN INCLUDE -->	

	





	
	<header>
		<div class="nav__menu-opener">
			<svg class="icon icon-menu">
				<use xlink:href="#icon-menu"></use>
			</svg>
			<svg class="icon icon-cross visuallyhidden">
				<use xlink:href="#icon-cross"></use>
			</svg>
		</div>	
		<nav class="">
			<ul>
				<li class="current"><a href="">Home</a></li>
				<li><a href="">Resume</a></li>
				<li><a href="">Gallery</a></li>
				<li><a href="">Footage</a></li>
				<li><a href="">Contact</a></li>
			</ul>
		</nav>	
				
		<h1>Amelia Fowler</h1>
	</header>