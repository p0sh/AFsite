	
	<div class="footerangle2">
	<footer>
		<a class="CTA" href="contact.html">Contact Amelia</a>
		<p class="spreadlove">spread &hearts;</p>
	</footer>
	</div>
	


<script src="js/zepto.min.js"></script>

<script>
$(document).ready(function () {

// open/close menu
	$( ".nav__menu-opener" ).click(function() {
	  $( ".icon-menu" ).toggleClass( "visuallyhidden" );
	  $( ".icon-cross" ).toggleClass( "visuallyhidden" );
	  $( ".nav__menu-opener" ).toggleClass( "open" );
	  $( "nav" ).toggleClass( "open" );
	});

// close menu when menu item is clicked
	$( ".nav--main .nav li" ).click(function() {
	  $( ".nav--main .nav" ).removeClass( "open" );
	});
	

/* -end- */
 });
</script>

</body>

</html>