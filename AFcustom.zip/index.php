<?php get_header(); ?>



	<div class="angle2">
	<section class="page_intro">
		
		<div class="headshot">
			<img src="img/Purple%20Shirt_800%20copy.jpg">
		</div>
		
		
		<a class="CTA" href="mailto:thing@email.com">Contact: thing@email.com</a>
		<p>Amelia Fowler, a native of Brooklyn, New York has been seen in commercial spots for Cablevision, the History Channel, IFC, as well as comedy venues throughout the Northeast with her fellow cast mates of the improv troupes "Comedy Sportz-New York," and "Eight is Never Enough."</p>

	</section>
	</div>	
	
<!--  3 MOST RECENT APPEARANCES -->
<!-- NOTE: THESE CONTENT CHUNKS PROBABLY NEED CUSTOM FIELDS IN WP -->
	<section class="content">
		
		<div class="chunk appearance">
			<h1>Category</h1> 
			<h2>Title of show</h2>
			<p>Description, HEY THESE DETAILS ELEMENTS NEED TO BE OPTIONAL IN THE CMS, WHAT IF THERE'S NO LOCATION BC IT'S A TV SHOW. Etiam molestie lacus dui, dapibus facilisis nibh maximus id. Duis condimentum iaculis massa, id iaculis lacus lacinia varius. In tempus scelerisque molestie. Fusce cursus ut mi a sollicitudin. Nunc et nunc eu justo aliquet eleifend et sed tellus. Morbi sit amet neque sed nisl semper mollis vitae quis sapien. Nullam faucibus vel mi et dictum.</p>
			
			<div class="details">
				<p id="tickets"><a class="CTA" href="#">Buy tickets</a></p>
				<p id="location"><span class="detail-data">Location:</span> Big Awesome Theater</p>
				<p id="date"><span class="detail-data">Date:</span> June 33rd - July 34th</p>
				<p id="time"><span class="detail-data">Time:</span> Daily at 7pm and 10pm</p>
			</div>

		</div>
		
		<div class="chunk appearance">
			<h1>Category</h1> 
			<h2>Title of show</h2>

			<img src="img/Purple%20Shirt_800%20copy.jpg" alt="Purple%20Shirt_800%20copy">
			
			<p>Description, In hac habitasse platea dictumst. In ultrices lectus id faucibus mollis. In hac habitasse platea dictumst. Etiam commodo mi in magna mattis, in vestibulum enim eleifend. Etiam molestie lacus dui, dapibus facilisis nibh maximus id. Duis condimentum iaculis massa, id iaculis lacus lacinia varius. In tempus scelerisque molestie. Fusce cursus ut mi a sollicitudin. Nunc et nunc eu justo aliquet eleifend et sed tellus. Morbi sit amet neque sed nisl semper mollis vitae quis sapien. Nullam faucibus vel mi et dictum.</p>

			<div class="details">
				<p id="tickets"><a class="CTA" href="#">Buy tickets</a></p>
				<p id="location"><span class="detail-data">Location:</span> Big Awesome Theater</p>
				<p id="date"><span class="detail-data">Date:</span> June 33rd - July 34th</p>
				<p id="time"><span class="detail-data">Time:</span> Daily at 7pm and 10pm</p>
			</div>

		</div>
				
		<div class="chunk appearance">
			<h1>Category</h1> 
			<h2>Title of show</h2>

			<img src="img/Purple%20Shirt_800%20copy.jpg" alt="Purple%20Shirt_800%20copy">
						
			<p>Description, In hac habitasse platea dictumst. In ultrices lectus id faucibus mollis. In hac habitasse platea dictumst. Etiam commodo mi in magna mattis, in vestibulum enim eleifend. Etiam molestie lacus dui, dapibus facilisis nibh maximus id. Duis condimentum iaculis massa, id iaculis lacus lacinia varius. In tempus scelerisque molestie. Fusce cursus ut mi a sollicitudin. Nunc et nunc eu justo aliquet eleifend et sed tellus. Morbi sit amet neque sed nisl semper mollis vitae quis sapien. Nullam faucibus vel mi et dictum.</p>
			
			<div class="details">
				<p id="tickets"><a class="CTA" href="#">Buy tickets</a></p>
				<p id="location"><span class="detail-data">Location:</span> Big Awesome Theater</p>
				<p id="date"><span class="detail-data">Date:</span> June 33rd - July 34th</p>
				<p id="time"><span class="detail-data">Time:</span> Daily at 7pm and 10pm</p>
			</div>

		</div>
				
	</section>


<?php get_footer(); ?>